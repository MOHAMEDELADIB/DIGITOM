package com.ih.ali

import android.support.v7.app.AppCompatActivity
import android.os.Bundle


class welcome : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

    }

}
