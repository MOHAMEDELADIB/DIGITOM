package com.ih.ali.API

data class RegisterData( var email:String , var api_token:String)
data class loginData(var username : String ,var password :String,var auth_token:String, var non_field_errors :String)
data class resetData( var email:String , var api_otp:String)



//
//{
//    "name": "test",
//    "email": "ali@gmail.com",
//    "api_token": "e3O5DU5E0eS3Ths8JRznNohTMRnQhTo5s7aqxUz96PQ4YOojReqM29dFn9ft",
//    "updated_at": "2019-09-01 23:22:39",
//    "created_at": "2019-09-01 23:22:39",
//    "id": 1
//}