package com.ih.ali.API

import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @POST("register")
    @FormUrlEncoded
    @Headers("Accept: application/json")
    fun register(
        @Field("email") email:String,
        @Field("password") password:String
    ): Call<RegisterData>

    @POST("login")
    @FormUrlEncoded
    @Headers("Accept: application/json")
    fun login(
        @Field("username") username:String,
        @Field("password") password:String
    ): Call<loginData>

    @POST("reset")
    @FormUrlEncoded
    @Headers("Accept: application/json")
    fun reset(
        @Field("email") email:String
    ): Call<resetData>

    @POST("passwordrest")
    @FormUrlEncoded
    @Headers("Accept: application/json")
    fun resetpassword(
        @Field("password") password:String
    ): Call<RegisterData>

}