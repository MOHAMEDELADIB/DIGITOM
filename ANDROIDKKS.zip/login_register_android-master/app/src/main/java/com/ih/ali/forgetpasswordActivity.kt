package com.ih.ali


import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.ih.ali.API.ApiService
import com.ih.ali.API.URL
import com.ih.ali.API.resetData
import kotlinx.android.synthetic.main.activity_forget_password.*
import kotlinx.android.synthetic.main.activity_sign_up.*
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory


class
forgetpasswordActivity : AppCompatActivity() {
    var myshered: SharedPreferences? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forget_password)
        val etmail = findViewById(R.id.mail_surest) as EditText
        sback2.setOnClickListener {
            val it = Intent(this@forgetpasswordActivity, main::class.java)
            startActivity(it)
        }
        restpassword.setOnClickListener {
            if(etmail.text.toString().trim().isNotEmpty() && etmail.text.toString().trim().isNotBlank()){
                if(etmail.length() >2) {
                    progressBarpass.visibility = View.VISIBLE
                    rstpassword(mail_surest.text.toString())
                }else{
                    val it = Intent(this@forgetpasswordActivity, authen::class.java)
                    startActivity(it)
                }
            }else {
                Toast.makeText(applicationContext,"The mail field is empty ",Toast.LENGTH_LONG).show();
            }

        }

    }

    fun rstpassword(email: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl(URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val api: ApiService = retrofit.create(ApiService::class.java)
        val call = api.reset(email)
        call.enqueue(object : Callback<resetData> {
            override fun onFailure(call: Call<resetData>, t: Throwable) {
                progressBarpass.visibility = View.GONE
                Toast.makeText(this@forgetpasswordActivity, " Cannot connect to the server", Toast.LENGTH_LONG).show()
            }
//need some modifications to otp
            override fun onResponse(call: Call<resetData>, response: Response<resetData>) {
                progressBarpass.visibility = View.GONE
                Toast.makeText(this@forgetpasswordActivity, response.body()!!.api_otp, Toast.LENGTH_LONG).show()
                myshered = getSharedPreferences("myshared", 0)
                var editor: SharedPreferences.Editor = myshered!!.edit()
                editor.putString("otp", response.body()!!.api_otp)
                editor.commit()
                val it = Intent(this@forgetpasswordActivity, authen::class.java)
                startActivity(it)
            }
        })

    }
}
