package com.ih.ali

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_authen.*


class authen : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_authen)
        otpact.setOnClickListener {
            val it = Intent(this@authen, passrst::class.java)
            startActivity(it)
        }
        sback3.setOnClickListener {
            val it = Intent(this@authen, main::class.java)
            startActivity(it)
        }

    }

}
