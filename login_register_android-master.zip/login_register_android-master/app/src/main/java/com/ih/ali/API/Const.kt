package com.ih.ali.API

val URL:String = "https://android200200.pythonanywhere.com/api/auth/token/"