package com.ih.ali

import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.ih.ali.API.ApiService
import com.ih.ali.API.RegisterData
import com.ih.ali.API.URL
import com.ih.ali.API.loginData
import kotlinx.android.synthetic.main.activity_authen.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_passrst.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class passrst : AppCompatActivity() {
    var myshered2 : SharedPreferences? =null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_passrst)
        done.setOnClickListener {
            progressBarnpass.visibility = View.VISIBLE
            restorepass(password_nw.text.toString())
        }


    }

    fun restorepass(password:String){
        val retrofit = Retrofit.Builder()
            .baseUrl(URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val api: ApiService = retrofit.create(ApiService::class.java)
        val call = api.resetpassword(password)
        call.enqueue(object : Callback<RegisterData> {
            override fun onFailure(call: Call<RegisterData>, t: Throwable) {
                progressBarnpass.visibility = View.GONE

                Toast.makeText(this@passrst,"Unable to connect to server" , Toast.LENGTH_LONG).show()
            }

            override fun onResponse(call: Call<RegisterData>, response: Response<RegisterData>) {
                progressBarnpass.visibility = View.GONE

                Toast.makeText(this@passrst,response.body()!!.api_token , Toast.LENGTH_LONG).show()
                myshered2 = getSharedPreferences("myshared2", 0)
                var editor: SharedPreferences.Editor = myshered2!!.edit()
                editor.putString("token",response.body()!!.api_token)
                editor.commit()
                val it =   Intent(this@passrst,welcome::class.java)
                startActivity(it)

            }

        })

    }

}
